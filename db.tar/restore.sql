--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE fpdb;
--
-- Name: fpdb; Type: DATABASE; Schema: -; Owner: amin
--

CREATE DATABASE fpdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE fpdb OWNER TO amin;

\connect fpdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fp_city_aggregation; Type: TABLE; Schema: public; Owner: amin
--

CREATE TABLE public.fp_city_aggregation (
    "time" character varying(20) NOT NULL,
    city character varying(50) NOT NULL,
    product_id character varying(10) NOT NULL,
    price character varying(10),
    quantity character varying(6),
    has_sold character varying(6)
);


ALTER TABLE public.fp_city_aggregation OWNER TO amin;

--
-- Name: fp_store_aggregation; Type: TABLE; Schema: public; Owner: amin
--

CREATE TABLE public.fp_store_aggregation (
    market_id character varying(10) NOT NULL,
    product_id character varying(10) NOT NULL,
    has_sold character varying(7),
    tot_price character varying(10)
);


ALTER TABLE public.fp_store_aggregation OWNER TO amin;

--
-- Name: fp_store_data; Type: TABLE; Schema: public; Owner: amin
--

CREATE TABLE public.fp_store_data (
    "time" character varying(20) NOT NULL,
    province character varying(50),
    city character varying(50),
    market_id character varying(10) NOT NULL,
    product_id character varying(10) NOT NULL,
    price character varying(7),
    quantity character varying(5),
    has_sold character varying(5)
);


ALTER TABLE public.fp_store_data OWNER TO amin;

--
-- Data for Name: fp_city_aggregation; Type: TABLE DATA; Schema: public; Owner: amin
--

COPY public.fp_city_aggregation ("time", city, product_id, price, quantity, has_sold) FROM stdin;
\.
COPY public.fp_city_aggregation ("time", city, product_id, price, quantity, has_sold) FROM '$$PATH$$/3196.dat';

--
-- Data for Name: fp_store_aggregation; Type: TABLE DATA; Schema: public; Owner: amin
--

COPY public.fp_store_aggregation (market_id, product_id, has_sold, tot_price) FROM stdin;
\.
COPY public.fp_store_aggregation (market_id, product_id, has_sold, tot_price) FROM '$$PATH$$/3197.dat';

--
-- Data for Name: fp_store_data; Type: TABLE DATA; Schema: public; Owner: amin
--

COPY public.fp_store_data ("time", province, city, market_id, product_id, price, quantity, has_sold) FROM stdin;
\.
COPY public.fp_store_data ("time", province, city, market_id, product_id, price, quantity, has_sold) FROM '$$PATH$$/3195.dat';

--
-- Name: fp_city_aggregation fp_city_aggregation_pkey; Type: CONSTRAINT; Schema: public; Owner: amin
--

ALTER TABLE ONLY public.fp_city_aggregation
    ADD CONSTRAINT fp_city_aggregation_pkey PRIMARY KEY ("time", city, product_id);


--
-- Name: fp_store_aggregation fp_store_aggregation_pkey; Type: CONSTRAINT; Schema: public; Owner: amin
--

ALTER TABLE ONLY public.fp_store_aggregation
    ADD CONSTRAINT fp_store_aggregation_pkey PRIMARY KEY (market_id, product_id);


--
-- Name: fp_store_data fp_store_data_pkey; Type: CONSTRAINT; Schema: public; Owner: amin
--

ALTER TABLE ONLY public.fp_store_data
    ADD CONSTRAINT fp_store_data_pkey PRIMARY KEY ("time", market_id, product_id);


--
-- PostgreSQL database dump complete
--

